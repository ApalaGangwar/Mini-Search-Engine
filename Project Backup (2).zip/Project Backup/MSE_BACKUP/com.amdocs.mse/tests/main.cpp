#include "../include/AuthenticationSystem.h"
#include "../include/DocumentManager.h"
#include "../include/User.h"
#include <iostream>

int main() {
    AuthenticationSystem authSystem("users.txt");
    string loggedInUsername;
    bool loggedIn = false;
    int choice;

    while (true) {
        if (!loggedIn) {
            cout << "\n===== Authentication Menu =====\n";
            cout << "1. Register\n2. Login\n3. Exit\nEnter choice: ";
            cin >> choice;

            switch (choice) {
            case 1:
                authSystem.registerUser();
                break;
            case 2:
                loggedIn = authSystem.loginUser(loggedInUsername);
                break;
            case 3:
                cout << "Exiting the program.\n";
                return 0;
            default:
                cout << "Invalid choice. Try again.\n";
                break;
            }
        } else {
            cout << "\n===== User Menu =====\n";
            cout << "1. Create Document\n";
            cout << "2. Append to Document\n";
            cout << "3. Search Documents\n";
            cout << "4. Display Documents\n";
            cout << "5. Update Password\n";
            cout << "6. Delete Account\n";
            cout << "7. Logout\n";
            cout << "Enter choice: ";
            cin >> choice;

            switch (choice) {
            case 1:
                DocumentManager::createDocument(loggedInUsername);
                break;
            case 2:
                DocumentManager::appendToDocument(loggedInUsername);
                break;
            case 3:
                DocumentManager::searchDocuments(loggedInUsername);
                break;
            case 4:
                DocumentManager::displayDocuments(loggedInUsername);
                break;
            case 5:
                authSystem.updatePassword(loggedInUsername);
                break;
            case 6:
                authSystem.deleteUserAccount(loggedInUsername);
                loggedIn = false; // After deleting account, user is logged out
                break;
            case 7:
                cout << "Logging out...\n";
                loggedIn = false;
                loggedInUsername = ""; // Clear the username on logout
                break;
            default:
                cout << "Invalid choice. Try again.\n";
                break;
            }
        }
    }
}
