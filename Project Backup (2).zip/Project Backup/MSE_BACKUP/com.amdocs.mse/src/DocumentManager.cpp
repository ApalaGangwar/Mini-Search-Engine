#include "../include/DocumentManager.h"
#include <iostream>
#include <fstream>
#include <filesystem>
using namespace std;
namespace fs = std::filesystem;

void DocumentManager::createDocument(const string &username) {
    string docName, content;
    cout << "Enter document name (without extension): ";
    cin >> docName;
    docName = username + "_" + docName + ".txt";

    ofstream outFile(docName);
    if (outFile.is_open()) {
        cout << "Enter content (enter 'END' to finish):" << endl;
        cin.ignore();
        while (getline(cin, content) && content != "END") {
            outFile << content << endl;
        }
        outFile.close();
        cout << "Document created successfully!\n";
    } else {
        cout << "Unable to open document for writing!\n";
    }
}

void DocumentManager::appendToDocument(const string &username) {
    string docName, content;
    cout << "Enter document name (without extension): ";
    cin >> docName;
    docName = username + "_" + docName + ".txt"; // Document name includes username

    ofstream outFile(docName, ios::app); // Open file in append mode
    if (outFile.is_open()) {
        cout << "Enter content to append (enter 'END' to finish):" << endl;
        cin.ignore(); // Ignore leftover newline from previous input
        while (getline(cin, content) && content != "END") {
            outFile << content << endl;
        }
        outFile.close();
        cout << "Content appended successfully!" << endl;
    } else {
        cout << "Unable to open document for appending!" << endl;
    }
}
void DocumentManager::searchDocuments(const string &username) {
    string searchTerm, line;
    cout << "Enter search term: ";
    cin >> searchTerm;

    bool found = false;
    for (const auto &entry : fs::directory_iterator(".")) {
        string fileName = entry.path().filename().string();
        if (fileName.find(username) != string::npos && fileName.find(".txt") != string::npos) {
            ifstream inFile(fileName);
            if (inFile.is_open()) {
                while (getline(inFile, line)) {
                    if (line.find(searchTerm) != string::npos) {
                        cout << "Found in " << fileName << ": " << line << endl;
                        found = true;
                    }
                }
                inFile.close();
            }
        }
    }
    if (!found) {
        cout << "No documents found containing the search term!" << endl;
    }
}

void DocumentManager::displayDocuments(const string &username) {
    cout << "Documents for " << username << ":" << endl;
    bool found = false;
    for (const auto &entry : fs::directory_iterator(".")) {
        string fileName = entry.path().filename().string();
        if (fileName.find(username) != string::npos && fileName.find(".txt") != string::npos) {
            cout << fileName << endl;
            found = true;
        }
    }
    if (!found) {
        cout << "No documents found for this user!" << endl;
    }
}

// Define appendToDocument, searchDocuments, and displayDocuments similarly
