#ifndef USER_H
#define USER_H

#include <string>
using namespace std;

class User {
public:
    string username;
    string password;

    User(string uname, string pass);

    static string maskPassword(const string &password);
};

#endif
