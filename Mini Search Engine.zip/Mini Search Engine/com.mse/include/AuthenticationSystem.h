#ifndef AUTHENTICATIONSYSTEM_H
#define AUTHENTICATIONSYSTEM_H

#include <string>
using namespace std;

class AuthenticationSystem {
private:
    string userFile;

public:
    AuthenticationSystem(string file);

    bool userExists(const string &username);
    void registerUser();
    bool loginUser(string &loggedInUsername);
    void updatePassword(const string &username);
    void deleteUserAccount(const string &username);
};

#endif
