#ifndef DOCUMENTMANAGER_H
#define DOCUMENTMANAGER_H

#include <string>
using namespace std;

class DocumentManager {
public:
    static void createDocument(const string &username);
    static void appendToDocument(const string &username);
    static void searchDocuments(const string &username);
    static void displayDocuments(const string &username);
};

#endif
