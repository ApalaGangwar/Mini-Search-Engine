#include "../include/AuthenticationSystem.h"
#include "../include/User.h"
#include <iostream>
#include <fstream>

AuthenticationSystem::AuthenticationSystem(string file) : userFile(file) {}

bool AuthenticationSystem::userExists(const string &username) {
    ifstream file(userFile);
    string storedUsername, storedPassword;
    while (file >> storedUsername >> storedPassword) {
        if (storedUsername == username) {
            return true;
        }
    }
    return false;
}

void AuthenticationSystem::registerUser() {
    string username, password;
    cout << "Enter Username: ";
    cin >> username;

    if (userExists(username)) {
        cout << "Username already exists. Please choose another one.\n";
        return;
    }

    cout << "Enter Password: ";
    cin >> password;

    ofstream file(userFile, ios::app);
    file << username << " " << User::maskPassword(password) << endl;

    cout << "Registration successful!\n";
}

bool AuthenticationSystem::loginUser(string &loggedInUsername) {
    string username, password;
    cout << "Enter Username: ";
    cin >> username;
    cout << "Enter Password: ";
    cin >> password;

    ifstream file(userFile);
    string storedUsername, storedPassword;
    while (file >> storedUsername >> storedPassword) {
        if (storedUsername == username && storedPassword == User::maskPassword(password)) {
            cout << "Login successful!\n";
            loggedInUsername = username;
            return true;
        }
    }
    cout << "Invalid username or password.\n";
    return false;
}

void AuthenticationSystem::updatePassword(const string &username) {
    cout << "Enter new password: ";
    string newPassword;
    cin >> newPassword;

    string tempFile = "temp.txt";
    ifstream file(userFile);
    ofstream temp(tempFile);

    string storedUsername, storedPassword;
    bool updated = false;

    while (file >> storedUsername >> storedPassword) {
        if (storedUsername == username) {
            temp << storedUsername << " " << User::maskPassword(newPassword) << endl;
            updated = true;
        } else {
            temp << storedUsername << " " << storedPassword << endl;
        }
    }

    file.close();
    temp.close();
    remove(userFile.c_str());
    rename(tempFile.c_str(), userFile.c_str());

    cout << (updated ? "Password updated successfully!\n" : "User not found.\n");
}

void AuthenticationSystem::deleteUserAccount(const string &username) {
    string tempFile = "temp.txt";
    ifstream file(userFile);
    ofstream temp(tempFile);

    string storedUsername, storedPassword;
    bool deleted = false;

    while (file >> storedUsername >> storedPassword) {
        if (storedUsername != username) {
            temp << storedUsername << " " << storedPassword << endl;
        } else {
            deleted = true;
        }
    }

    file.close();
    temp.close();
    remove(userFile.c_str());
    rename(tempFile.c_str(), userFile.c_str());

    cout << (deleted ? "Account deleted successfully!\n" : "User not found.\n");
}
