#include "../include/User.h"

User::User(string uname, string pass) : username(uname), password(pass) {}

string User::maskPassword(const string &password) {
    string masked = password;
    char key = 'K';
    for (auto &ch : masked) {
        ch ^= key;
    }
    return masked;
}
